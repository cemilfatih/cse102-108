#ifndef _UTIL_H_
#define _UTIL_H_

void part1();

void part2();

void part3();

void part4();

#endif /* _UTIL_H_ */
