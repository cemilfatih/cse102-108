#include <stdio.h>
#include "util.h"

int main(){


        printf(">>>>>GCD PART<<<<< \n");
        part1();
        
        printf(">>>>>SUMS PART<<<<< \n");
        part2();
        
        printf(">>>>>MULTIPLY PART<<<<< \n");
	part3();
	
	printf(">>>>><<<<< \n");
	part4();
	
}
