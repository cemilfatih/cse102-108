#include <stdio.h>
#include "util.h"


void main() {

  part1();
  printf("\n");
  part2();
  printf("\n");
  part3();

}
